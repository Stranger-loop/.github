import express from "express";
import http from "http";
import { Server } from "socket.io";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import crypto from "crypto";

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: false } });
const PORT = process.env.PORT || 3000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;
const rooms = new Map();
const waiting = { text: [], video: [] };
const reports = [];
const recentMessages = []; // In-memory only; cleared on restart. Disclosed in public notice.
const RATE_WINDOW_MS = 10_000;
const messageTimes = new Map();

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "16kb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false }));
app.use(express.static("public"));

function safeText(value, max = 1000) {
  return String(value ?? "").replace(/[<>]/g, "").trim().slice(0, max);
}
function roomOf(socket) { return socket.data.roomId && rooms.get(socket.data.roomId); }
function leaveRoom(socket) {
  const room = roomOf(socket);
  if (room) {
    const otherId = room.members.find(id => id !== socket.id);
    if (otherId) io.to(otherId).emit("peer-left");
    rooms.delete(room.id);
    for (const id of room.members) {
      const peer = io.sockets.sockets.get(id);
      if (peer) { peer.leave(room.id); peer.data.roomId = null; }
    }
  }
  for (const mode of ["text", "video"]) {
    waiting[mode] = waiting[mode].filter(id => id !== socket.id);
  }
  socket.data.roomId = null;
}
function joinQueue(socket, mode, interests = []) {
  leaveRoom(socket);
  const normalized = [...new Set(interests.map(x => safeText(x, 24).toLowerCase()).filter(Boolean))].slice(0, 5);
  socket.data.mode = mode;
  socket.data.interests = normalized;
  const queue = waiting[mode];
  let matchIndex = queue.findIndex(id => {
    const peer = io.sockets.sockets.get(id);
    if (!peer) return true;
    const theirs = peer.data.interests || [];
    return !normalized.length || !theirs.length || normalized.some(x => theirs.includes(x));
  });
  if (matchIndex < 0) {
    queue.push(socket.id);
    socket.emit("queue", { mode });
    return;
  }
  const peerId = queue.splice(matchIndex, 1)[0];
  const peer = io.sockets.sockets.get(peerId);
  if (!peer) { queue.push(socket.id); socket.emit("queue", { mode }); return; }
  const roomId = crypto.randomUUID();
  const room = { id: roomId, mode, members: [peerId, socket.id], createdAt: Date.now() };
  rooms.set(roomId, room);
  for (const id of room.members) {
    const member = io.sockets.sockets.get(id);
    member.data.roomId = roomId;
    member.join(roomId);
  }
  io.to(peerId).emit("matched", { roomId, mode, initiator: true });
  io.to(socket.id).emit("matched", { roomId, mode, initiator: false });
}
io.on("connection", socket => {
  socket.on("join", payload => {
    if (!payload?.adultConfirmed || !payload?.policyAccepted) {
      socket.emit("app-error", "Please confirm you are 18+ and accept the privacy notice and community rules.");
      return;
    }
    const mode = payload.mode === "video" ? "video" : "text";
    joinQueue(socket, mode, Array.isArray(payload.interests) ? payload.interests : []);
  });
  socket.on("message", payload => {
    const room = roomOf(socket);
    if (!room || room.mode !== "text") return;
    const now = Date.now();
    const times = (messageTimes.get(socket.id) || []).filter(t => now - t < RATE_WINDOW_MS);
    if (times.length >= 8) { socket.emit("app-error", "Slow down a little before sending more messages."); return; }
    times.push(now); messageTimes.set(socket.id, times);
    const text = safeText(payload?.text, 1000);
    if (!text) return;
    const entry = { roomId: room.id, sender: socket.id, text, at: now };
    recentMessages.push(entry);
    if (recentMessages.length > 1000) recentMessages.shift();
    socket.to(room.id).emit("message", { text, at: now, mine: false });
    socket.emit("message", { text, at: now, mine: true });
  });
  socket.on("signal", payload => {
    const room = roomOf(socket);
    if (!room || room.mode !== "video") return;
    const peerId = room.members.find(id => id !== socket.id);
    if (peerId) io.to(peerId).emit("signal", payload);
  });
  socket.on("next", () => {
    const mode = socket.data.mode || "text";
    leaveRoom(socket);
    joinQueue(socket, mode, socket.data.interests || []);
  });
  socket.on("report", payload => {
    const room = roomOf(socket);
    if (!room) return;
    const reason = safeText(payload?.reason || "Other", 120);
    reports.push({ id: crypto.randomUUID(), roomId: room.id, reporter: socket.id, reason, at: Date.now() });
    socket.emit("report-received");
    const peerId = room.members.find(id => id !== socket.id);
    if (peerId) io.to(peerId).emit("peer-left");
    leaveRoom(socket);
  });
  socket.on("leave", () => leaveRoom(socket));
  socket.on("disconnect", () => { leaveRoom(socket); messageTimes.delete(socket.id); });
});

app.get("/health", (_req, res) => res.json({ ok: true, activeRooms: rooms.size }));
app.get("/admin/summary", (req, res) => {
  if (!ADMIN_TOKEN || req.get("x-admin-token") !== ADMIN_TOKEN) return res.status(401).json({ error: "Unauthorized" });
  res.json({
    activeRooms: [...rooms.values()].map(r => ({ mode: r.mode, participants: r.members.length, startedAt: r.createdAt })),
    reports: reports.slice(-100).reverse(),
    // Messages are visible only through this authenticated endpoint and are kept in memory only.
    recentTextMessages: recentMessages.slice(-100).reverse().map(m => ({ ...m, sender: "anonymous" }))
  });
});

server.listen(PORT, "0.0.0.0", () => console.log(`StrangerLoop listening on ${PORT}`));
